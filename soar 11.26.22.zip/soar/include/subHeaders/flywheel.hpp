#pragma once
#include "main.h"

void takeBackHalf(int target);
void setFlywheel(int fPwr);

// driver control funcs
void setFlywheelMotors();
void setFlywheelandIndTime(int pwr, int indPwr, int time);