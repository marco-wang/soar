#include "main.h"

// variables for TBH function
int target;
int current;
int output;
double tbh;
double gain;
double error;
double pastError;

void takeBackHalf(int target){
    current = flywheel.get_actual_velocity();

    // TD: set gain & tbh vars
    gain = 0.7;
    tbh = 0;

    error = target - current; // calculate the error;
    output += gain * error; // integrate the output;
    if (std::signbit(error)!= std::signbit(pastError)) { // if zero crossing,
        output = 0.5 * (output + tbh); // then Take Back Half
        tbh = output; // update Take Back Half variable
        pastError = error; // and save the previous error
    }

    flywheel.move_velocity(output);
}

// driver control funcs
void setFlywheelMotors(){
    // bottom to spin flywheel
    flywheel.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
        flywheel.move_velocity(435);
    }
    else if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
        flywheel.brake();
    }
}

void setFlywheelandIndTime(int pwr, int indPwr, int time){
    flywheel = pwr;
    pros::delay(4000);
    intake = indPwr;
    pros::delay(time * 0.2);
    intake = 0;
    pros::delay(1000);
    intake = indPwr;
    pros::delay(time * 0.8);
    flywheel = 0;
    intake = 0;
}