#pragma once
#include "main.h"

void leftAuto();
void rightAuto();
void skills();