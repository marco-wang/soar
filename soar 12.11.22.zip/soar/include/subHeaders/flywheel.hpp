#pragma once
#include "main.h"
#include "pros/rtos.hpp"

void takeBackHalf(int target);
void setFlywheel(int fPwr);

// driver control funcs
void setFlywheelMotors();
void setFlywheelandIndTime(int pwr, int indPwr);