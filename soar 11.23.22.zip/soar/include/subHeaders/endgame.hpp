#pragma once
#include "main.h"

void launch();