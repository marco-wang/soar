#pragma once
#include "main.h"

void setRoller(int rPwr);
void setRollerMotors();
void setRollerTime(int rPwr, int time);