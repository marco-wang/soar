#include "main.h"
#include "subHeaders/drive.hpp"
#include "subHeaders/flywheel.hpp"

void leftAuto(){
    setDriveTime(-50, -50, 200);
    setRollerTime(-60, 400);
    setDriveTime(50, 50, 400);
    setDriveTime(-30, 30,  230);
    setFlywheelandIndTime(120, -100, 2600);
}

void rightAuto(){
    setDriveTime(50, 50, 1600);
    setDriveTime(-50, 50, 400);
    setDriveTime(-50, -50, 1500);
    setDriveTime(-30, -90, 600);
    setRollerTime(-70, 700);
    setDriveTime(50, 50, 200);
    setDriveTime(30, -30,  115);
    setFlywheelandIndTime(120, -120, 1600);
}