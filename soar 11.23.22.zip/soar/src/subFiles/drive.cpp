#include "main.h"

// helper funcs
void setDrive(int left, int right){
    lBack = left;
    lFront = left;
    rBack = right;
    rFront = right;
}

void resetEncoders(){
    lBack.tare_position();
    lFront.tare_position();
    rBack.tare_position();
    rFront.tare_position();
}

double avgEncoderValue(){
    return (fabs(lBack.get_position())
            + fabs(lFront.get_position()) 
            + fabs(rBack.get_position()) 
            + fabs(rFront.get_position())) / 4;
}

// driver control funcs
void setDriveMotors(){
    int power = cece.get_analog(ANALOG_LEFT_Y); // power of forward/backward movement
    int turn = cece.get_analog(ANALOG_RIGHT_X); // power of turn movement

    // dead zone (prevents stick drift)
    if(abs(power) < 5){
        power = 0;
    }
    if(abs(turn) < 5){
        turn = 0;
    }

    setDrive(power + turn, power - turn); // arcade drive
}

void setDriveTime(int left, int right, int time){
    setDrive(left, right);
    pros::delay(time);
    setDrive(0,0);
}

void translate(int units, int volts){
    int direction = abs(units) / units;
    // reset encoders + gyro
    resetEncoders();
    gyro.reset();

    // go until units reached
    while(avgEncoderValue() < abs(units)){
        // set drive + self-correcting code according to gyro angle
        setDrive(volts * direction + gyro.get_heading() * 10, volts * direction - gyro.get_heading() * 10);
        // pros::delay(10);
    }

    // brake
    setDrive(-10 * direction, -10 * direction);
    pros::delay(100);

    // drive back to neutral
    setDrive(0, 0);
}

void rotate(int degrees, int volts){
    int direction = abs(degrees) / degrees;
    // reset gyro
    gyro.reset();

    // turn until degrees met
    setDrive(-volts * direction, volts * direction);
    while (fabs(gyro.get_heading()) < abs(degrees) - 3){ // -3 prevents overshoot 
        pros::delay(10);
    }

    pros::delay(100); // momentum check

    // check overshoot
    if(fabs(gyro.get_heading()) > abs(degrees)){
        setDrive(volts * direction * 0.5, -volts * direction * 0.5);
        while(fabs(gyro.get_heading()) > abs(degrees)){
            pros::delay(10);
        }   
    }

    // check undershoot
    if(fabs(gyro.get_heading()) < abs(degrees)){
        setDrive(-volts * direction * 0.4, volts * direction * 0.4);
        while(fabs(gyro.get_heading()) > abs(degrees)){
            pros::delay(10);
        }   
    }

    // reset drive
    setDrive(0, 0);
}