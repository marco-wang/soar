#include "main.h"

void launch(){
    if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_UP)){
        endgame1.set_value(true);
        endgame2.set_value(true);
    }
}