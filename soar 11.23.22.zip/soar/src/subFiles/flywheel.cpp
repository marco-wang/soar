#include "main.h"


// driver control funcs
void setFlywheelMotors(){
    // bottom to spin flywheel
    flywheel.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
        flywheel.move_velocity(435);
    }
    else if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_B)){
        flywheel.brake();
    }
}

void setFlywheelandIndTime(int pwr, int indPwr, int time){
    flywheel = pwr;
    pros::delay(4000);
    indexer = indPwr;
    pros::delay(time * 0.2);
    indexer = 0;
    pros::delay(1000);
    indexer = indPwr;
    pros::delay(time * 0.8);
    flywheel = 0;
    indexer = 0;
}