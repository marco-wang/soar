#include "main.h"

// helpers
void setRoller(int rPwr){
    roller = rPwr;
}

// driver control funcs
void setRollerMotors(){
    int rollerPower = 0;
    // button X rotate roller
    if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_X)){
        rollerPower = 127;
    }

    setRoller(rollerPower);
}

void setRollerTime(int rPwr, int time){
    setRoller(rPwr);
    setDrive(-10, -10);
    pros::delay(time);
    setRoller(0);
    setDrive(0,0);
}