#include "main.h"

// helpers
void setIntake(int intPwr, int indPwr){
    intake = intPwr;
    indexer = indPwr;
}

// driver control funcs
void setIntakeMotors(){
    int intakePower = 0;
    int indexerPower = 0;
    // bottom outtake, top intake
    if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
        intakePower = 127;
        indexerPower = 127;
    }
    else if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
        intakePower = -127;
        indexerPower = 0;
    }
    else if(cece.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){
        intakePower = 0;
        indexerPower = -127;
    }

    setIntake(intakePower, indexerPower);
}

void setIntakeTime(int intPwr, int indPwr, int time){
    setIntake(intPwr, indPwr);
    pros::delay(time);
    setIntake(0, 0);
}